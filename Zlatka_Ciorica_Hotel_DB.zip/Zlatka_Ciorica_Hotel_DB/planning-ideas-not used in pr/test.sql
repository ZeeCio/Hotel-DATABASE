use zlatkacioricahoteldb;
SELECT * from reservations where firstname='Jeremiah' and lastname=' Pendergrass';

ALTER TABLE reservations
where firstname='Jeremiah' and lastname=' Pendergrass'
DROP FOREIGN KEY fk_reservations_guestsid;

ALTER  TABLE reservations 
DROP reservations_guestid,guests.firstname where firstname='Jeremiah' and lastname=' Pendergrass';