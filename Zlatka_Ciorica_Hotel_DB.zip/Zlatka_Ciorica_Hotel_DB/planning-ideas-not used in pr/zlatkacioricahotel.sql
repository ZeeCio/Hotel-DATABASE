DROP DATABASE IF EXISTS zlatkacioricahotel;

CREATE DATABASE  zlatkacioricahotel;

USE  zlatkacioricahotel;

CREATE TABLE RoomDescription (
  RoomNumber Int,
  RoomType Varchar(50),
  Amenities Varchar(80),
  AdaAccess Varchar (10),
  StandardOccupancy INT,
  MaxOccupancy INT,
  Price DECIMAL(7,2),
  ExtraPerson INT,
  CONSTRAINT PK_Description 
    	PRIMARY KEY (RoomNumber)
);

-- CREATE TABLE Address (
  -- State Varchar(20),
 -- Address Varchar(100),
 -- City Varchar(50),
  -- Zip INT,
  -- GuestID INT
  -- CONSTRAINT pk_Address 
    	-- PRIMARY KEY (StateID)
  -- CONSTRAINT FK_Address_Address
    	 -- FOREIGN KEY (GuestID)
    	 -- REFERENCES Address(GuestID)
-- );

CREATE TABLE Reservations (
  ReservationID INT AUTO_INCREMENT,
  CONSTRAINT PK_Reservations 
    	PRIMARY KEY (ReservationID),
  RoomNumber INT,
  -- CONSTRAINT FK_Reservations_RoomReservation
		-- FOREIGN KEY (RoomNumber)
		-- REFERENCES RoomReservation (RoomNumber),
  GuestID INT,
  -- CONSTRAINT FK_Reservations_GuestReservation
		 -- FOREIGN KEY (GuestID)
		 -- REFERENCES GuestReservation (GuestID),
  Adults Int,
  Children Int,
  StartDate Varchar(25),
  EndDate Varchar(25),
  TotalCost DECIMAL(7,2)
);

 
CREATE TABLE Guests (
  GuestID INT AUTO_INCREMENT,
  CONSTRAINT PK_Guest 
    	PRIMARY KEY (GuestID),
  ReservationID INT,
  FirstName Varchar(100),
  LastName Varchar(100),
  Phone Varchar(25),
  State  Varchar(20),
  Address Varchar(100),
  City Varchar(50),
  Zip INT
  -- CONSTRAINT FK_Guests_Address
        -- FOREIGN KEY (StateID)
	    -- REFERENCES Address (StateID),
  -- CONSTRAINT FK_Guests_GuestReservation
		-- FOREIGN KEY (ReservationID)
		-- REFERENCES GuestReservation (ReservationID)
);


CREATE TABLE GuestReservation (
GuestID INT,
ReservationID INT,
CONSTRAINT PK_GuestReservation
       PRIMARY KEY (GuestID, ReservationID),
CONSTRAINT FK_GuestReservation_Guests
	    FOREIGN KEY (GuestID)
	    REFERENCES Guests(GuestID),
CONSTRAINT FK_GuestReservation_Reservations
    	FOREIGN KEY (ReservationID)
    	REFERENCES Reservations(ReservationID)
);




CREATE TABLE RoomReservation (
ReservationID INT,
RoomNumber INT,
CONSTRAINT PK_RoomReservation
		PRIMARY KEY (RoomNumber, ReservationID)
-- CONSTRAINT FK_RoomReservation_RoomDescription
    	-- FOREIGN KEY (RoomNumber)
    	-- REFERENCES RoomDescription(RoomNumber),
-- CONSTRAINT FK_RoomReservation_Reservations
    	-- FOREIGN KEY (ReservationID)
    	-- REFERENCES Reservations(ReservationID)
);




ALTER TABLE Reservations ADD CONSTRAINT FK_Reservations_RoomReservation FOREIGN KEY(RoomNumber) REFERENCES RoomReservation (RoomNumber) ON UPDATE CASCADE; 
ALTER TABLE Guests ADD CONSTRAINT FK_Guests_GuestReservation FOREIGN KEY(ReservationID) REFERENCES GuestReservation (ReservationID) ON UPDATE CASCADE; 
ALTER TABLE RoomReservation ADD CONSTRAINT FK_RoomReservation_RoomDescription FOREIGN KEY(RoomNumber) REFERENCES RoomDescription(RoomNumber) ON UPDATE CASCADE; 
ALTER TABLE RoomReservation ADD CONSTRAINT FK_RoomReservation_Reservations FOREIGN KEY(ReservationID) REFERENCES Reservations(ReservationID) ON UPDATE CASCADE; 
-- ALTER TABLE Guests ADD CONSTRAINT FK_Guests_Address FOREIGN KEY(State) REFERENCES Address (State) ON UPDATE CASCADE; 


-- old code 

-- ALTER TABLE Reservations ADD CONSTRAINT FK_Reservations_GuestReservation FOREIGN KEY(GuestID) REFERENCES Address(GuestID) ON UPDATE CASCADE ON DELETE RESTRICT; 



-- ALTER TABLE Address ADD CONSTRAINT FK_Address_Address FOREIGN KEY(GuestID) REFERENCES Address(GuestID) ON UPDATE CASCADE ON DELETE RESTRICT; 


-- ALTER TABLE GuestAddress ADD CONSTRAINT FK_GuestAddress_Guests FOREIGN KEY(GuestID) REFERENCES GuestAddress(GuestID) ON UPDATE CASCADE ON DELETE RESTRICT; 
-- ALTER TABLE GuestAddress ADD CONSTRAINT FK_GuestAddress_Address FOREIGN KEY(StateID) REFERENCES Address(StateID) ON UPDATE CASCADE ON DELETE RESTRICT; 










