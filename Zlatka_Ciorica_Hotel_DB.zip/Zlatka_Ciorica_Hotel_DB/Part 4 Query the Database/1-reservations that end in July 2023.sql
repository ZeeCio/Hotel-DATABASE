USE zlatkacioricahoteldb;

select 
g.firstname,
g.lastname,
r.roomNumber,
r.startdate,
r.enddate 
from guests g 
inner join reservations r ON g.GuestID=r.GuestID
where r.enddate >= '%/07/2023';