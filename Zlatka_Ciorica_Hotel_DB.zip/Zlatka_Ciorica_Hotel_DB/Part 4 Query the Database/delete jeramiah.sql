use zlatkacioricahoteldb;

DELETE FROM guests
WHERE firstname = 'Jeremiah' LIMIT 1;
 

 select*from guests;
 

DELETE FROM reservations
WHERE guestID = 8 LIMIT 1;

  select*from reservations;