USE zlatkacioricahoteldb;

Select 
rd.RoomNumber,
r.Reservationid,
rd.price
from roomdescription rd 
left join reservations r ON r.RoomNumber=r.RoomNumber;
