USE zlatkacioricahoteldb;

Select 
g.firstname,
g.lastname,
COUNT(r.GuestId) AS TotalReservations
from reservations r 
INNER join guests g ON G.GuestID=r.GuestID
GROUP BY g.FirstName
ORDER BY TotalReservations DESC, g.LastName;
