USE zlatkacioricahoteldb;

Select 
g.firstname,
g.lastname,
r.roomnumber,
r.startdate,
r.adults,
r.children
from reservations r 
inner join guests g ON g.GuestID=r.GuestID
where g.FirstName >= 'Zlatka' and g.lastname='Ciorica';