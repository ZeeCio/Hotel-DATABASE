use zlatkacioricahoteldb;

Select 
g.phone as 'phone number search:',
g.firstname,
g.lastname,
g.address
from guests g 
order by g.lastname asc;
