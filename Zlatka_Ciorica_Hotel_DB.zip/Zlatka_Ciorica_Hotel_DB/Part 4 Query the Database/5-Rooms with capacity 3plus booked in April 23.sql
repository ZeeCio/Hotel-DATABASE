USE zlatkacioricahoteldb;

Select 
r.Reservationid as 'Rooms with capacity 3+ booked in April/23',
r.startdate,
r.enddate,
r.RoomNumber
from reservations r
left join roomdescription rd ON r.RoomNumber=rd.RoomNumber
right join rooms rm ON rd.RoomType = rm.RoomType
where rm.StandardOccupancy >=3 and r.StartDate like '%4/%/2023' or r.EndDate like '%4/%/2023';
