USE zlatkacioricahoteldb;

Select 
r.Reservationid as 'Reservations for rooms with Jacuzzi',
g.FirstName,
g.lastname,
r.startdate,
r.enddate,
r.RoomNumber
from guests g
left join reservations r On g.GuestID=r.GuestID
join roomdescription rd ON r.RoomNumber=rd.RoomNumber
join rooms rm ON rd.RoomType = rm.RoomType
where rm.amenities like '%Jacuzzi';


