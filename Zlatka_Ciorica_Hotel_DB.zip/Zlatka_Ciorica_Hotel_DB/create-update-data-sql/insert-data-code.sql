use zlatkacioricahotel;
select * from roomdescription;

INSERT INTO roomdescription (RoomNumber,RoomType, Amenities,AdaAccess,StandardOccupancy,MaxOccupancy,Price,ExtraPerson)
VALUES (201,'Double','Microwave,Jacuzzi','No',2,4,199.99,10),
(203,'Double','Microwave,Jacuzzi','No',2,4,199.99,10),
(301,'Double','Microwave,Jacuzzi','No',2,4,199.99,10),
(303,'Double','Microwave,Jacuzzi','No',2,4,199.99,10),
(206,'Single','Microwave,Refrigerator','Yes',2,2,149.99,NULL),
(208,'Single','Microwave,Refrigerator','Yes',2,2,149.99,NULL),	
(308,'Single','Microwave,Refrigerator','Yes',2,2,149.99,NULL),	
(306,'Single','Microwave, Refrigerator','Yes',2,2,149.99,NULL),	
(205,'Single','Microwave,Refrigerator, Jacuzzi','No',2,2,174.99,NULL),	
(207,'Single','Microwave,Refrigerator, Jacuzzi','No',2,2,174.99,NULL),	
(305,'Single','Microwave,Refrigerator, Jacuzzi','No',2,2,174.99,NULL),	
(307,'Single','Microwave,Refrigerator, Jacuzzi','No',2,2,174.99,NULL),	
(401,'Suite','Microwave,Refrigerator, Oven','Yes',3,8,399.99,20),
(402,'Suite','Microwave,Refrigerator, Oven','Yes',3,8,399.99,20),
(202,'Double','Refrigerator','Yes',2,4,174.99,10),
(204,'Double','Refrigerator','Yes',2,4,174.99,10),
(302,'Double','Refrigerator','Yes',2,4,174.99,10),
(304,'Double','Refrigerator','Yes',2,4,174.99,10)
;

select * from guests;

INSERT INTO guests (GuestID,FirstName,LastName,Phone,Adults,Children)
VALUES ('Zlatka',' Ciorica',2915530509),
('Mack',' Simmer',2915530508),
('Bettyann',' Seery',4782779632),
('Duane',' Cullison',3084940198),
('Karie',' Yang',2147300298),
('Aurore',' Lipton',3775070974),
('Zachery',' Luechtefeld',8144852615),
('Jeremiah',' Pendergrass',2794910960),
('Walter',' Holaway',4463966785),
('Wilfred',' Vise',8347271001),
('Maritza',' Tilton',4463516860),
('Joleen',' Tison',2318932755);

