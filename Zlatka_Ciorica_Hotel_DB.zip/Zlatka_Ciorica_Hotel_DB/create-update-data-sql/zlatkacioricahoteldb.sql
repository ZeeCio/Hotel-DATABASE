DROP DATABASE IF EXISTS zlatkacioricahoteldb;

CREATE DATABASE  zlatkacioricahoteldb;

USE  zlatkacioricahoteldb;

CREATE TABLE Guests (
  GuestID INT AUTO_INCREMENT,
  CONSTRAINT PK_Guest 
    	PRIMARY KEY (GuestID),
  FirstName Varchar(100),
  LastName Varchar(100),
  Phone Varchar(25),
  Address Varchar(100),
  City Varchar(50),
  State  Varchar(20),
  Zip INT
  -- CONSTRAINT FK_Guests_Address
        -- FOREIGN KEY (StateID)
	    -- REFERENCES Address (StateID),
  -- CONSTRAINT FK_Guests_GuestReservation
		-- FOREIGN KEY (ReservationID)
		-- REFERENCES GuestReservation (ReservationID)
);

CREATE TABLE Rooms (
RoomType Varchar(25),
Amenities VARCHAR(100),
StandardOccupancy INT,
MaxOccupancy INT,
 CONSTRAINT PK_Rooms 
    	PRIMARY KEY (RoomType)
);

CREATE TABLE RoomDescription (
  RoomNumber Int,
  RoomType Varchar(50),
  CONSTRAINT FK_ReservationDescription_Rooms
		FOREIGN KEY (RoomType)
		REFERENCES Rooms (RoomType),
  AdaAccess Varchar (10),
  Price DECIMAL(7,2),
  ExtraPerson INT,
  CONSTRAINT PK_Description 
    	PRIMARY KEY (RoomNumber)
);


CREATE TABLE Reservations (
  ReservationID INT AUTO_INCREMENT,
  CONSTRAINT PK_Reservations 
    	PRIMARY KEY (ReservationID),
  RoomNumber INT,
  -- CONSTRAINT FK_Reservations_RoomDescription
		-- FOREIGN KEY (RoomNumber)
		-- REFERENCES RoomDescription (RoomNumber),
  GuestID INT,
  -- CONSTRAINT FK_Reservations_Guests
		 -- FOREIGN KEY (GuestID)
		 -- REFERENCES Guests (GuestID),
  Adults Int,
  Children Int,
  StartDate Varchar(25),
  EndDate Varchar(25),
  TotalCost DECIMAL(7,2)
);

ALTER TABLE RoomDescription ADD CONSTRAINT FK_RoomDescription_Rooms FOREIGN KEY(RoomType) REFERENCES Rooms(RoomType) ON UPDATE CASCADE ON DELETE CASCADE;  

ALTER TABLE Reservations ADD CONSTRAINT FK_Reservations_RoomDescription FOREIGN KEY(RoomNumber) REFERENCES RoomDescription (RoomNumber) ON UPDATE CASCADE ON DELETE CASCADE;

ALTER TABLE Reservations ADD CONSTRAINT FK_Reservations_Guests FOREIGN KEY(GuestID) REFERENCES Guests(GuestID) ON UPDATE CASCADE ON DELETE CASCADE; 
